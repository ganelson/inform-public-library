## Introduction

Complex Listing provides two significant abilities: the ability to change the way a list is delimited (that is, to use semi-colons, sentence fragments, dashes, or othermore exotic techniques, instead of the usual commas with a final "and"); and the ability to determine an ordering for the list according to criteria of our choosing.

Because Complex Listing is relatively powerful, the complete description of what it does may be a bit daunting, especially for less experienced users. It may be more congenial to skip down to the examples and then return to the full instructions later.

_Modification history_. Version 10 tidies up the implementation considerably, and corrects two long-standing bugs:
- `enumerative` style not enumerating in the `bare` articulation, and
- `"[prepared list delimited in ... style]"` wrongly taking the indefinite article as if it were `"[a prepared list delimited in ... style]"`.

## Preparing a list

There are three stages to setting up and printing a complex list: marking the items we are going to include; arranging the list in order; and printing the list.

Preparation consists of choosing which objects to list, and then "registering" the result. This can be done in a single step where the objects meet some easily expressed condition, like so:

>	phrase: prepare a list of (description of objects)
>	
>	This assigns the `marked for special listing` property to exactly those
>	objects which match the description, and then registers the result.

For instance, we might say:

	prepare a list of animals which are visible.

Alternatively, we can write out own code to apply `marked for special listing` to just the objects we want, but if so then we must finish with:

>	phrase: register things marked for listing
>	
>	Completes the decision of what to list. It sets up a table, called the
>	Table of Scored Listing, which contains all the items that we are going
>	to describe in our list, in two columns: `output` (the thing that is going
>	to be named) and `assigned score` (the value we've given this item to order
>	it with respect to everything else). Assigned scores are initially all 0,
>	and the table is initially sorted in the order: directions, then rooms, then
>	everything else.

## Ordering the list

At this point we may optionally choose to arrange the list in order in some way. One approach is to write our own phrase to go through the `Table of Scored Listing` and assign scores to each item.

For instance, we might write a phrase to order the `Table of Scored Listing` according to the monetary value of items, their current relevance to the plot, their size, etc., etc., etc. -- it can be anything we want to include for the purpose of adding nuance to the descriptive prose. As a commonly-needed strategy for this:

>	phrase: order list by length
>	
>	Works through the `Table of Scored Listing` and assigns each item a score
>	so that higher scores correspond to longer printed names.

This is provided as a convenience, but it's actually quite simple:

	To order list by length:
		repeat through Table of Scored Listing:
			now the assigned score entry is the number of characters in the printed name of the output entry.

## Printing the list

>	phrase: say prepared list
>	
>	Sorts the `Table of Scored Listing` and then prints items in that order.

The sorting necessary is done by running the `list arranging activity`, but
by default this contains only the `sort complex lists in ascending score order rule`, which does just what it says. A `sort complex lists in descending score order rule` is also provided, but by default it is not used.

>	phrase: say a prepared list
>	
>	Like `say prepared list`, but giving each item the indefinite article.

>	phrase: say the prepared list
>	
>	Like `say prepared list`, but giving each item the definite article.

>	phrase: say is-are the prepared list
>	
>	Like `say prepared list`, but prefacing the list by `is` or `are` according
>	to how many things are in it.

>	phrase: say is-are a prepared list
>	
>	Like `say is-are prepared list`, but giving each item the indefinite article.

>	phrase: say is-are prepared list
>	
>	Like `say is-are prepared list`, but giving each item the definite article.

## List styles

The `list style` is the way items are delimited within it. We provide eight of these:

list style        | example
:---------------- | :------
`sequential`      | ``apple, banana and cherry``
`disjunctive`     | ``apple, banana or cherry``
`semi-colon`      | ``apple; banana; cherry``
`comma`           | ``apple, banana, cherry``
`null`            | ``apple banana cherry``
`hyperconnective` | ``apple and banana and cherry``
`fragmentary`     | ``Apple. Banana. Cherry``
`enumerated`      | ``(1) apple; (2) banana; (3) cherry``

except that the `Use serial comma` option inserts commas before the final
``and`` or ``or``.

`Enumerated` presents a list with each element numbered, and makes use of this
phrase, which may sometimes be useful in other contexts:

>	phrase: decide what number is the current enumeration
>	
>	Unless a complex listing is being printed, this returns 1. But if it
>	is, it returns the position in the list (counting from 1) of the item
>	currently being printed.

To adopt these styles, the following variations are available:

>	phrase: say prepared list delimited in (chosen style - a list style) style
>	
>	Like `say prepared list`, but in the chosen style.

>	phrase: say a prepared list delimited in (chosen style - a list style) style
>	
>	Like `say a prepared list`, but in the chosen style.

>	phrase: say the prepared list delimited in (chosen style - a list style) style
>	
>	Like `say the prepared list`, but in the chosen style.

>	phrase: say is-are prepared list delimited in (chosen style - a list style) style
>	
>	Like `say is-are prepared list`, but in the chosen style.

>	phrase: say is-are a prepared list delimited in (chosen style - a list style) style
>	
>	Like `say is-are a prepared list`, but in the chosen style.

>	phrase: say is-are the prepared list delimited in (chosen style - a list style) style
>	
>	Like `say is-are the prepared list`, but in the chosen style.

Of course, there are times when even this does not give adequate flexibility. This whole process is carried out by the `delimiting a list` activity, and if we want, we can write our own rules for delimiting a list. The current version is carried out by the `standard delimiting rule`: see the source for details.

But if we liked we could replace this with more complicated logic to apply under some circumstances; for instance, instructions to group items in different numbers of combinations so that we generate lists like ``a chicken, a horse, a duck; a red hen; a heron.`` This gets increasingly detailed and picky, but provides significant leverage towards writing routines that will generate human-like prose.
