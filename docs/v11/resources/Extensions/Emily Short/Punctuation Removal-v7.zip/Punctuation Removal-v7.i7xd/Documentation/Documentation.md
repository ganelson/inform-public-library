## Introduction

Punctuation Removal provides phrases for removing unwanted punctuation marks from
the player's command before attempting to understand it.

These phrases should be used during the `after` stage of the `reading a command`
activity, so for example:

	After reading a command:
		remove stray punctuation.

_Compatibility_. This extension works on all platforms, with two different
implementations: one for the Z-machine and one for everything else.

## Phrases for removing punctuation

>	phrase: to remove exclamation points
>
>	Removes all instances of the ``!`` character from the player's command.
>	This phrase should be used only within the `after reading a command` rulebook.

>	phrase: remove question points
>
>	Removes all instances of the ``?`` character from the player's command.
>	This phrase should be used only within the `after reading a command` rulebook.

>	phrase: remove quotes
>
>	Removes all instances of the ``"`` character from the player's command.
>	This phrase should be used only within the `after reading a command` rulebook.

>	phrase: remove stray punctuation
>
>	Removes all instances of the ``!``, ``?`` or ``"`` characters from the player's command:
>	equivalent to performing all three of `remove exclamation points`, `remove question points`,
>	and `remove quotes`.
>	This phrase should be used only within the `after reading a command` rulebook.

Also provided, but not included in `remove stray punctuation`, are:

>	phrase: remove periods
>
>	Removes all instances of the ``.`` character from the player's command.
>	This phrase should be used only within the `after reading a command` rulebook.

This should be used sparingly, since the player's command might reasonably include
multiple actions separated by full stops: ``TAKE FISH. EAT FISH``. Similarly dangerous is:

>	phrase: remove apostrophes
>
>	Removes all instances of the ``'`` character from the player's command.
>	This phrase should be used only within the `after reading a command` rulebook.

A more common need is to be able to parse titles such as ``MR.`` and ``MRS.`` sensibly.
Inform reads any full stop as the end of the sentence, which leads to such exchanges as:

	>X MR. SINISTER.
	You see nothing special about Mr. Sinister.

	That's not a verb I recognise.

because Inform has interpreted as though the player had typed

	>X MR.
	You see nothing special about Mr. Sinister.
	
	>SINISTER
	That's not a verb I recognise.

To get around this, we want to remove full stops only when they appear as parts
of standard titles. "Punctuation Removal" provides the phrase

>	phrase: resolve punctuated titles
>
>	Turns all instances in the player's command of ``MR.``, ``MRS.``, ``PROF.``,
>	``ST.``, ``DR.``, and ``REV.`` into ``MR``, ``MRS``, ``PROF``, ``ST``, ``DR``, and ``REV`` respectively.
>	This phrase should be used only within the `after reading a command` rulebook.

Now with this rule in place:

	After reading a command:
		resolve punctuated titles.

we get such output as:

	>X ME. X MR. SINISTER.
	As good-looking as ever.

	You see nothing special about Mr. Sinister.
