## Introduction

Locksmith adds implicit handling of doors and containers so that lock manipulation is automatic if the player has the necessary keys.

One thing Locksmith does not handle is allowing skeleton keys that unlock multiple locks. This functionality costs some memory overhead, so it is not included compulsorily in "Locksmith", but we can have it by also including `Skeleton Keys by Emily Short`.

## The keyless actions

Locksmith will try opening all doors that an actor tries to pass through; try closing all lockables before locking them; and try unlocking all locked items before opening them. It tries to provide an intelligent default if no key is specified, so that ``LOCK DOOR`` will work if the player is holding the correct key.

This is done with two new actions, `unlocking keylessly` and `locking keylessly`. These co-exist with the usual actions of `unlocking` and `locking`, which require a specific key to be named. The command grammar for the verbs ``OPEN``, ``UNCOVER``, ``UNWRAP``, ``LOCK`` and ``UNLOCK`` is reconstructed entirely, and there is a new sense of ``PUT X ON Y`` for putting keys onto keychains (see below).

By default, these actions are described as other automatic actions usually are in Inform: the player sees something like ``(first unlocking...)`` before he opens the door. The `Use sequential action` option is provided for the case where we would prefer to see ``You unlock the door.`` instead.

## Key-refusal

If the player tries to open a door but does not have the right key, they receive a key-refusal message, such as ``You lack a key that fits the red chest.`` This is produced with the text substitution `[key-refusal for X]`, and can be customised by writing specific re-definitions of that phrase like so:

	To say key-refusal for (locked-thing - a container):
		say "You will be unable to see the contents of [the locked-thing] until you find the appropriate key."

	To say key-refusal for (locked-thing - the red chest):
		say "The red chest resists all your attempts because you do not have the magic orb."

## The passkey and keychain kinds

Locksmith defines two new kinds.

A `passkey` is a key which will name itself in inventory listings after use. Once the passkey has been identified, the game also automates taking the key before using it on the door it matches. Keys the player has never successfully identified, or keys not defined as belonging to the passkey kind, will not behave this way. Passkeys are also renamed if the player has seen another character use them successfully.

The `unbolting` relation is used to keep track of what the player knows about keys, and the verb `to unbolt` means this. To say that `X unbolts Y` is to say that the player _knows_ that `X` will unlock `Y`. It is possible to change this directly (`now X unbolts Y`) to give the player new knowledge about the functions of keys, or indeed to take away such knowledge (`now X does not unbolt Y`).

A `keychain` is a portable `supporter` which can have passkets, and only passkeys, put onto them. Keys on a keychain can be used as though they were in the player's hand, and will not be automatically removed for locking and unlocking actions.

## Debugging

Finally, Locksmith provides the debugging command ``UNLOCKALL``, only identified in debugging compilations of the game.  If during play we type ``UNLOCKALL``, all locks in the game will magically spring open.
