## Introduction

This simple extension replaces the default behavior of Inform, which allows one key per
lock, with a more generous system in which unlocking applies to multiple objects.
That means that it is possible to write a skeleton key like so:

	Every door is unlocked by the skeleton key.

Or to have duplicate keys to the same lock:

	The oak door is unlocked by the warden's key.
	The oak door is unlocked by the librarian's key.

(It was already possible for one key to fit multiple locks, but not for multiple
keys to fit the same lock.)

_Compatibility._ This works on either Z-machine or Glulx, but it incurs some
dynamic memory cost, which may be tricky for Z-machine projects.

## How it works

"Skeleton Keys" works by changing the Standard Rules definition of the `lock-fitting`
relation, which is normally:

	Lock-fitting relates one thing (called the matching key) to various things.

so that it instead reads:

	Lock-fitting relates various things to various things.

Because it is possible for more than one key to unlock a given door, the property
`matching key` no longer exists: there's no single matching key.

In a project which also includes `Locksmith by Emily Short`, that's the only
change that "Skeleton Keys" makes, and the business of locking and unlocking
is entirely handled by "Locksmith".

In a project which does _not_ include `Locksmith by Emily Short`, two rules
from the Standard Rules are overridden to ensure that skeleton keys function
as intended:

	can't unlock without the correct key rule
	can't lock without the correct key rule

These are each replaced with the new:

	can't use an incorrect key rule

_Note_. In earlier releases of this extension, the new rule was called
the `right second rule`. It has been renamed for clarity.
