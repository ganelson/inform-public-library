## Introduction

This extension is a kit for writers who want to make realistic simulations of the physical world, making fairly accurate calculations in the metric system for measurements used as standard in science. Unusually for an Inform extension, it defines _only_ kinds of value, notations for writing them, and specifications for how they multiply. (For example, a mass multiplied by an acceleration is a force, and a length multiplied by a length is an area.)

Metric units are sometimes associated with the French Revolution or with Napoleon, but they were made official by an international treaty in May 1875. In 1960 this system was further standardised and renamed the "Système international d'unités", so that science textbooks talk about "SI units", but it's really the same thing. This extension follows SI conventions for everything except temperature, where it uses centigrade rather than Kelvin.

This extension does not define miles, pounds and ounces, or other "Imperial measures" standardised by the British Empire, and still used in some parts of the world. See the example below for how to add Imperial units.

_Compatibility_. This extension is intended for use with projects which store 32-bit numbers at run-time, for example for the default Glulx virtual machine. It also assumes that floating-point arithmetic is available, which will be the case on almost any modern platform. For projects which for some reason can only use integer arithmetic, the otherwise deprecated extension `Approximate Metric Units by Graham Nelson` should be used instead.

## Basic use

This extension defines kinds of values for some 22 SI units in common usage, and more than 100 notations for them. It also makes sure they multiply correctly. For instance, a mass times an acceleration produces a force, so

	say "You feel a force of [2kg times 5 m/ss]."

will produce the text ``You feel a force of 10N.`` The easiest way to see how all these units combine is to run one of the examples below and look at the Kinds index which results.

For each unit, both names and notations are allowed. Thus `2 kilograms` is
equivalent to `2kg`. Moreover, since most units have multiple notations, we can often print back the same value in a variety of ways. For instance, here are some alternative ways to say a mass stored in `m0` and a volume in `C`:

| Text substitution              | Expands to |
| :----------------------------- | :-------------------- |
| `"[m0 in metric units]"`       | ``2.04kg`` |
| `"[m0 in kg]"`                 | ``2.04kg`` |
| `"[m0 in g]"`                  | ``2040g`` |
| `"[m0 in kilograms]"`          | ``2.04 kilograms`` |
| `"[C in metric units]"`        | ``47 ml`` |
| `"[C in milliliters]"`         | ``47 milliliters`` |
| `"[C in millilitres]"`         | ``47 millilitres`` |
| `"[C to the nearest 5 ml]"`    | ``45 ml`` |

The above examples make use of built-in features of Inform to provide two useful ways to change the text produced:

- Any Inform value can be rounded, not just ordinary numbers, so any unit can be rounded `to the nearest` increment.
- The text expansion `... in metric units` prints any value of any of these units in its most natural notation: ``2.04kg`` is thought to be better than ``2040g``, but ``981g`` would be better than ``0.981kg``.

## Catalogue of units included

| kind of value               | notations allowed     |
| :-------------------------- | :-------------------- |
| `length` |  `1m`, `1 meter`, `1mm`, `1 millimeter`, `1cm`, `1 centimeter`, `1km`, `1 kilometer` |
| `mass` |  `1kg`, `1 kilogram`, `1g`, `1 gram`, `1 tonne` |
| `elapsed time` |  `1s`, `1 second`, `1 min`, `1 hr`, `1 day`, `1 week` |
| `electric current` |  `1A`, `1 amp`, `1mA`, `1 milliamp` |
| `temperature` |  `1C`, `1 degree centigrade`, `1 degree Celsius` |
| `luminosity` |  `1 cd`, `1 candela` |
| `frequency` |  `1 Hz`, `1 Hertz`, `1 mHz`, `1 millihertz`, `1 kHz`, `1 kilohertz` |
| `force` |  `1N`, `1 Newton`, `1kN`, `1 kilonewton` |
| `energy` |  `1J`, `1 Joule`, `1mJ`, `1 millijoule`, `1kJ`, `1 kilojoule` |
| `pressure` |  `1Pa`, `1 Pascal`, `1kPa`, `1 kilopascal`, `1MPa`, `1 megapascal` |
| `power` |  `1W`, `1 Watt`, `1mW`, `1 milliwatt`, `1kW`, `1 kilowatt` |
| `electric charge` | `1 C`, `1 Coulomb`, `1 kC`, `1 kilocoulomb` |
| `voltage` |  `1V`, `1 volt`, `1mV`, `1 millivolt`, `1kV`, `1 kilovolt` |
| `luminance` |  `1 cd/sq m`, `1 candela per square meter` |
| `area` |  `1 sq m`, `1 square meter`, `1 sq cm`, `1 square centimeter`, `1 hectare` |
| `volume` |  `1 cu m`, `1 cubic meter`, `1 l`, `1 liter`, `1 cc`, `1 cubic centimeter`, `1 ml`, `1 milliliter` |
| `velocity` |  `1 m/s`, `1 meter per second`, `1 km/s`, `1 kilometer per second` |
| `acceleration` |  `1 m/ss` |
| `momentum` | `1 Ns`, `1 Newton-second` |
| `density` |  `1 kg/cu m`, `1 kilogram per cubic meter`, `1 g/cu m`, `1 gram per cubic meter`, `1 g/cc`, `1 gram per cubic centimeter` |
| `heat capacity` |  `1 J/C`, `1 Joule per degree centigrade` |
| `specific heat capacity` | `1 J/kg/C`, `1 Joule per kilogram per degree centigrade` |

Note that:
- This extension uses the term `mass` for what most people informally call "weight". So `showme 2 kilograms` produces the output ``mass: 2.0kg``.
- The term `elapsed time` is used to distinguish this precise measurement from Inform's much vaguer built-in kind `time`, which is used for times of day such as `12:03 am`.
- Plurals are allowed: `6.2 grams`, `22 candelas per square meter`.
- `1C` is a temperature in centigrade, but `1 C` is an electric charge in Coulombs.
- Both common spellings of `meter`/`metre` and `liter`/`litre` are allowed, and similarly for derivations like `centimeter`/`centimetre`.
- However, the much less-used `gramme` is not allowed for `gram`.
- `Ton` is not allowed for `tonne`. It is too easily confused with the Imperial measure, which has a different value.

Imperial units such as `miles` or `ounces` are different ways of describing the same kinds of value: in the language of the table above, they are additional notations rather than additional kinds of value. See the example `The Empire Strikes Back` for how to add these.

## Units not included

We haven't included every SI unit. There are hundreds of kinds of value which turn up in physics, and we only include the commonest 25 or so. The missing ones which have named SI units are:

- absorbed radioactive dose (Grays)
- angle (measured in radians)
- catalytic activity (katals)
- chemical quantity (mole)
- electric capacitance (Farads)
- electric conductance (Siemens)
- electric resistance (Ohms)
- equivalent radioactive dose (Sieverts)
- inductance (Henries)
- luminous flux (lux)
- magnetic field (Teslas)
- magnetic flux (Webers)
- radioactivity (Becquerels)
- solid angle (steradians)

As can be seen, we've missed out units for chemistry, electromagnetic effects beyond the basic ones, and radioactivity. It would be easy to add any of these which might be needed:

	Electric resistance is a kind of value.

	1.0 Ohm (in metric units, in Ohms, singular) or 2 Ohms (in metric units, in Ohms, plural) specifies an electric resistance.

	Electric resistance times electric current specifies a voltage.

Similarly, there are many kinds of value which don't have named SI units, but where physicists write them down as compounds:

- angular momentum (Nms)
- angular velocity (rad/s, though Inform would probably use degrees/s)
- conductivity (S/m)
- electric field strength (V/m)
- energy density (J/cu m)
- jerk (m/sss)
- magnetic field strength (A/m)
- molar energy (J/mol)
- molar heat capacity (J/K/mol)
- molar volume (cu m/mole)
- permeability (H/m)
- permittivity (F/m)
- resistivity (Ohm metre)
- snap (m/ssss)
- specific energy (J/kg)
- specific volume (cu m/kg)
- surface tension (J/sq m)
- thermal conductivity (W/m/C)
- torque (Nm)
- viscosity (sq m/s)
- volumetric flow (cu m/s)
- wavenumber (1/m)

These are also easy to add as needed:

	Angular momentum is a kind of value.
	
	1.0 Nms specifies an angular momentum.
	
	Momentum times length specifies an angular momentum.
