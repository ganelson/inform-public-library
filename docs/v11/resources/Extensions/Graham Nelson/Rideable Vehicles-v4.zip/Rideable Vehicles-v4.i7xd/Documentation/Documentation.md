## Introduction

Inform's built-in `vehicle` kind assumes that the vehicle is a
container, which is fine for cars or hot-air balloons, but not so
good for a pony or a four-wheeled lawnmower, which one rides rather
than gets inside. Rideable Vehicles is an extension which creates
two more kinds: `rideable animal` (good for the pony) and
`rideable vehicle` (good for the lawnmower).

## Rideable animals and rideable vehicles

This is a simple extension written purely in Inform 7 source text, and is
quite easy to read. It does three things

**Defines two kinds**, `rideable animal` (a kind of `animal`) and `rideable vehicle`
(a kind of `supporter`):

	The pony is a rideable animal in the Forest Clearing.
	The lawnmover is a rideable vehicle in the Garden Shed.

The adjective `rideable` is not defined, to avoid ambiguities, but a new
adjective `vehicular` is defined to mean "a `vehicle` or a `rideable vehicle`
or a `rideable animal`". These are the three different kinds of thing which
can be used as a means of travel. For example:

	The Transport Museum is a room. "The Museum is filled with means
	of transport old and new, including [list of vehicular things in
	the Transport Museum]."

**Defines two actions**, `mounting something` and `dismounting`.
The parser commands ``MOUNT``, or equivalently ``RIDE``, and ``DISMOUNT``
result in these actions. For example:

	Instead of mounting the pony, say "The pony snorts and backs off."

results in

	>RIDE PONY
	The pony snorts and backs off.

Assuming you eventually succeed.

	>DISMOUNT
	You get off the pony.

The `mounting` action is implemented with the following rules:

	can't mount when mounted on an animal rule
	can't mount when mounted on a vehicle rule
	can't mount something unrideable rule
	can't mount something carried rule
	can't mount something unreachable rule
	standard mounting rule
	standard report mounting rule
	mounting excuses rule

And `dismounting` uses:

	can't dismount when not mounted rule
	standard dismounting rule
	standard report dismounting rule
	dismounting excuses rule

**Converts existing actions to mounting or dismounting**, where appropriate.
This is where the extension modifies the behaviour of actions in the Standard
Rules:
- The existing `stand up before going rule` is removed: this would normally block
  any `going` action when the player is on a `supporter`.
- The new `allow rideables to be going vehicles rule` enables the `going`
  action to work properly when the player is riding.
- The new `convert enter rideable animal to mount rule` and `convert enter rideable vehicle to mount rule`
  converts `entering` actions to `mounting` actions as needed.
- The new `convert get off rideable animal to dismount rule` and
  `convert get off rideable vehicle to dismount rule` similarly convert
  `getting off` to `dismounting`, if the actor is currently riding.
- The new `convert exit to dismount rule` likewise converts `exiting` to
  `dismounting`.
- And the new `steering rideable animals rule` converts requests to a rideable
  animal which the actor is riding into straightforward `going` actions.
  Thus ``PONY, GO EAST`` is equivalent to ``EAST`` if the player is riding the pony.
  (This works for rideable animals, but not rideable vehicles, which are assumed
  not to respond to the rider's voice.)

These conversions mean that rules like the following:

	Instead of mounting the tricycle when the transport pass is not carried by the player:
		say "The tricycle can only be ridden by those with a transport pass."

will catch both ``GET ON THE TRICYCLE`` and ``MOUNT TRICYCLE`` equally.
